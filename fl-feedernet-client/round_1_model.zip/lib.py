def print_test(name):
    print(name)
